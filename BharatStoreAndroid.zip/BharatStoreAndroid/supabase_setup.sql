-- Run once in Supabase: Dashboard > SQL Editor.
-- Creates a PUBLIC bucket "apks" for APK files (separate from your chat bucket "images").

insert into storage.buckets (id, name, public, file_size_limit)
values ('apks', 'apks', true, 52428800)          -- 50 MB = Supabase free-plan per-file maximum
on conflict (id) do update set public = true, file_size_limit = 52428800;

-- Anyone holding the publishable key may ADD new files to this bucket (developer.html uploads this way).
create policy "apks: allow uploads"
on storage.objects for insert to anon, authenticated
with check (bucket_id = 'apks');

-- Deliberately NO update/delete policy: nobody can overwrite or delete a published APK
-- through the public key. Each upload gets a unique path (<package>/<versionCode>_<timestamp>.apk).
-- Public buckets serve files by URL without a select policy.
