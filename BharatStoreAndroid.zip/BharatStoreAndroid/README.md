# BharatStore for Android

A native Android shell around your BharatWebStore (`app/src/main/assets/index.html` = patched `webstore.html`).
APKs are stored in Supabase Storage, listed in your Firebase `apps` node, and installed through Android's PackageInstaller.

## One-time setup
1. **Supabase:** open your project (the one BharatChat uses) > SQL Editor > run `supabase_setup.sql`. This creates a public `apks` bucket.
2. **Signing key** (needed so the store app can be updated later):
   ```
   keytool -genkeypair -v -keystore release.jks -alias bharatstore -keyalg RSA -keysize 2048 -validity 10000
   base64 -w0 release.jks     # copy the output
   ```
   Keep `release.jks` and its passwords safe. If you lose it you can never update the installed store app.
3. **GitHub:** create a repo, upload this whole folder, then Settings > Secrets and variables > Actions, add:
   `KEYSTORE_BASE64`, `KEYSTORE_PASSWORD`, `KEY_ALIAS` (bharatstore), `KEY_PASSWORD`.
4. Actions tab > "Build BharatStore APK" > Run workflow. Download `BharatStore-apk` from the run's artifacts.
5. Replace the web files on your host with the patched `developer.html`, `admin.html`, `webstore.html`.

## Publishing an app
developer.html > Publish > step 3 > fill package name + version code, choose the APK, deploy.
Admin approves it in admin.html. It then appears in the store with a real Install button.
To release an update: Edit the app, upload the new APK, raise the version code. Android only installs an update if the
version code is higher and the APK is signed with the same key as the installed one.

## Notes
- Android always shows its own confirmation dialog; silent installs are not possible.
- Users must allow "Install unknown apps" for BharatStore once (the store sends them to that settings screen).
- APK limit is 50 MB on the Supabase free plan. For bigger files, raise the plan limit or host on GitHub Releases
  (github.com is already allowed in `Installer.kt`; paste the release URL into `apkUrl`).
- Allowed download hosts are listed in `Installer.kt` (`ALLOWED_HOST_SUFFIXES`).
- To update the store UI without a new APK, host `webstore.html` yourself and set `STORE_URL` in `app/build.gradle.kts`.
