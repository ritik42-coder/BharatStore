package com.bharatstore.app

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageInstaller
import androidx.core.content.IntentCompat
import java.io.File

class InstallResultReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val id = intent.getStringExtra("appId") ?: return
        val status = intent.getIntExtra(PackageInstaller.EXTRA_STATUS, PackageInstaller.STATUS_FAILURE)
        val msg = intent.getStringExtra(PackageInstaller.EXTRA_STATUS_MESSAGE) ?: ""

        when (status) {
            PackageInstaller.STATUS_PENDING_USER_ACTION -> {
                // Android needs the user to confirm; show the system install dialog.
                val confirm = IntentCompat.getParcelableExtra(intent, Intent.EXTRA_INTENT, Intent::class.java)
                if (confirm != null) {
                    confirm.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    context.startActivity(confirm)
                }
                return
            }
            PackageInstaller.STATUS_SUCCESS -> Installer.emitStatus(id, "installed")
            PackageInstaller.STATUS_FAILURE_ABORTED -> Installer.emitStatus(id, "cancelled")
            PackageInstaller.STATUS_FAILURE_CONFLICT ->
                Installer.emitStatus(id, "failed", "Conflict: the installed copy was signed with a different key. Uninstall it first.")
            PackageInstaller.STATUS_FAILURE_INCOMPATIBLE ->
                Installer.emitStatus(id, "failed", "This app is not compatible with your device.")
            else -> Installer.emitStatus(id, "failed", if (msg.isNotBlank()) msg else "Install failed (code $status)")
        }
        intent.getStringExtra("path")?.let { File(it).delete() }
    }
}
