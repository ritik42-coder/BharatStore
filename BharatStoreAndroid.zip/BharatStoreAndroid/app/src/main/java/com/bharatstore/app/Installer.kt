package com.bharatstore.app

import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageInstaller
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.security.MessageDigest
import java.util.concurrent.Executors

/** Downloads an APK, verifies it, and hands it to the system PackageInstaller. */
object Installer {

    /** Only APKs from these hosts (and their subdomains) are downloaded. Edit if you host APKs elsewhere. */
    private val ALLOWED_HOST_SUFFIXES = listOf("supabase.co", "github.com", "githubusercontent.com")

    const val ACTION_RESULT = "com.bharatstore.app.INSTALL_RESULT"

    interface Listener {
        fun onProgress(id: String, pct: Int)
        fun onStatus(id: String, status: String, message: String)
    }

    @Volatile var listener: Listener? = null
    private val main = Handler(Looper.getMainLooper())
    private val pool = Executors.newFixedThreadPool(2)

    fun emitProgress(id: String, pct: Int) { main.post { listener?.onProgress(id, pct) } }
    fun emitStatus(id: String, status: String, msg: String = "") { main.post { listener?.onStatus(id, status, msg) } }

    private fun hostAllowed(url: String): Boolean {
        val u = try { URL(url) } catch (e: Exception) { return false }
        if (u.protocol != "https") return false
        val h = u.host.lowercase()
        return ALLOWED_HOST_SUFFIXES.any { h == it || h.endsWith(".$it") }
    }

    fun installedVersions(ctx: Context, pkgs: List<String>): Map<String, Long> {
        val out = HashMap<String, Long>()
        for (p in pkgs) {
            try {
                val pi = ctx.packageManager.getPackageInfo(p, 0)
                out[p] = versionOf(pi)
            } catch (_: PackageManager.NameNotFoundException) { }
        }
        return out
    }

    @Suppress("DEPRECATION")
    private fun versionOf(pi: android.content.pm.PackageInfo): Long =
        if (Build.VERSION.SDK_INT >= 28) pi.longVersionCode else pi.versionCode.toLong()

    fun openUnknownSourcesSettings(ctx: Context) {
        val i = Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:${ctx.packageName}"))
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        ctx.startActivity(i)
    }

    fun download(ctx: Context, id: String, url: String, pkg: String, expectedSha: String, expectedSize: Long) {
        val app = ctx.applicationContext
        if (!hostAllowed(url)) { emitStatus(id, "failed", "Download blocked: untrusted APK host"); return }
        if (!app.packageManager.canRequestPackageInstalls()) {
            openUnknownSourcesSettings(app)
            emitStatus(id, "needs_permission")
            return
        }
        pool.execute {
            val dir = File(app.cacheDir, "apks").apply { mkdirs() }
            val file = File(dir, "${id.replace(Regex("[^A-Za-z0-9_-]"), "_")}.apk")
            try {
                if (file.exists()) file.delete()
                val sha = MessageDigest.getInstance("SHA-256")
                val conn = URL(url).openConnection() as HttpURLConnection
                conn.connectTimeout = 20000; conn.readTimeout = 30000
                conn.instanceFollowRedirects = true
                if (conn.responseCode !in 200..299) throw RuntimeException("Server returned ${conn.responseCode}")
                val total = if (conn.contentLengthLong > 0) conn.contentLengthLong else expectedSize
                var done = 0L; var last = -1
                conn.inputStream.use { input ->
                    file.outputStream().use { out ->
                        val buf = ByteArray(64 * 1024)
                        while (true) {
                            val n = input.read(buf)
                            if (n < 0) break
                            out.write(buf, 0, n); sha.update(buf, 0, n); done += n
                            if (total > 0) {
                                val pct = ((done * 100) / total).toInt().coerceIn(0, 99)
                                if (pct != last) { last = pct; emitProgress(id, pct) }
                            }
                        }
                    }
                }
                emitStatus(id, "verifying")
                if (expectedSize > 0 && done != expectedSize) throw RuntimeException("Downloaded size does not match the listing")
                val hex = sha.digest().joinToString("") { "%02x".format(it) }
                if (expectedSha.isNotBlank() && !hex.equals(expectedSha.trim(), ignoreCase = true))
                    throw RuntimeException("Checksum mismatch: file was altered or corrupted")

                val info = app.packageManager.getPackageArchiveInfo(file.absolutePath, 0)
                    ?: throw RuntimeException("File is not a valid APK")
                if (pkg.isNotBlank() && info.packageName != pkg)
                    throw RuntimeException("APK package (${info.packageName}) does not match the listing ($pkg)")

                emitProgress(id, 100)
                commit(app, id, file, info.packageName)
            } catch (e: Exception) {
                file.delete()
                emitStatus(id, "failed", e.message ?: "Download failed")
            }
        }
    }

    private fun commit(ctx: Context, id: String, file: File, pkg: String) {
        val installer = ctx.packageManager.packageInstaller
        val params = PackageInstaller.SessionParams(PackageInstaller.SessionParams.MODE_FULL_INSTALL)
        params.setAppPackageName(pkg)
        if (Build.VERSION.SDK_INT >= 31)
            params.setRequireUserAction(PackageInstaller.SessionParams.USER_ACTION_NOT_REQUIRED)
        val sid = installer.createSession(params)
        emitStatus(id, "installing")
        installer.openSession(sid).use { session ->
            file.inputStream().use { input ->
                session.openWrite("base.apk", 0, file.length()).use { out ->
                    input.copyTo(out)
                    session.fsync(out)
                }
            }
            val intent = Intent(ctx, InstallResultReceiver::class.java)
                .setAction(ACTION_RESULT)
                .putExtra("appId", id)
                .putExtra("path", file.absolutePath)
            val flags = PendingIntent.FLAG_UPDATE_CURRENT or
                (if (Build.VERSION.SDK_INT >= 31) PendingIntent.FLAG_MUTABLE else 0)
            val pending = PendingIntent.getBroadcast(ctx, sid, intent, flags)
            session.commit(pending.intentSender)
        }
    }
}
