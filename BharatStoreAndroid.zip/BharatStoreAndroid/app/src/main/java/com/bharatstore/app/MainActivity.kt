package com.bharatstore.app

import android.annotation.SuppressLint
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import androidx.webkit.WebViewAssetLoader
import org.json.JSONArray
import org.json.JSONObject

class MainActivity : AppCompatActivity(), Installer.Listener {

    private lateinit var web: WebView
    private val assetHost = "appassets.androidplatform.net"

    private val storeHost: String? =
        if (BuildConfig.STORE_URL.isNotBlank()) Uri.parse(BuildConfig.STORE_URL).host else null

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        web = WebView(this)
        setContentView(web)

        val loader = WebViewAssetLoader.Builder()
            .setDomain(assetHost)
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()

        web.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            mediaPlaybackRequiresUserGesture = false
            allowFileAccess = false
            allowContentAccess = false
            mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
            cacheMode = WebSettings.LOAD_DEFAULT
        }

        web.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? =
                loader.shouldInterceptRequest(request.url)

            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                val host = request.url.host
                if (host == assetHost || (storeHost != null && host == storeHost)) return false
                // anything else (app websites, links) opens in the system browser, never inside the store
                try {
                    startActivity(Intent(Intent.ACTION_VIEW, request.url).addCategory(Intent.CATEGORY_BROWSABLE))
                } catch (_: Exception) { }
                return true
            }
        }

        web.addJavascriptInterface(Bridge(), "BharatNative")

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                // close an open app-detail modal first, then history, then exit
                val js = "(function(){var m=document.getElementById('appModal');" +
                    "if(m&&!m.classList.contains('hidden')){m.classList.add('hidden');document.body.style.overflow='';return 1;}return 0;})()"
                web.evaluateJavascript(js) { r ->
                    if (r == "1") return@evaluateJavascript
                    if (web.canGoBack()) web.goBack() else { isEnabled = false; onBackPressedDispatcher.onBackPressed() }
                }
            }
        })

        if (savedInstanceState == null) {
            val url = if (BuildConfig.STORE_URL.isNotBlank()) BuildConfig.STORE_URL
                      else "https://$assetHost/assets/index.html"
            web.loadUrl(url)
        } else {
            web.restoreState(savedInstanceState)
        }
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        web.saveState(outState)
    }

    override fun onStart() { super.onStart(); Installer.listener = this }
    override fun onStop() { if (Installer.listener === this) Installer.listener = null; super.onStop() }
    override fun onResume() { super.onResume(); runJs("window.BharatInstall&&window.BharatInstall.onInstalledChanged&&window.BharatInstall.onInstalledChanged()") }
    override fun onDestroy() { web.destroy(); super.onDestroy() }

    private fun runJs(code: String) = runOnUiThread { web.evaluateJavascript(code, null) }

    override fun onProgress(id: String, pct: Int) =
        runJs("window.BharatInstall&&window.BharatInstall.onProgress(${JSONObject.quote(id)},$pct)")

    override fun onStatus(id: String, status: String, message: String) =
        runJs("window.BharatInstall&&window.BharatInstall.onStatus(${JSONObject.quote(id)},${JSONObject.quote(status)},${JSONObject.quote(message)})")

    /** Exposed to the store page as window.BharatNative. Only our own store page is ever loaded in this WebView. */
    inner class Bridge {
        @JavascriptInterface fun isNative(): Boolean = true

        @JavascriptInterface fun getInstalled(pkgsJson: String): String {
            val arr = try { JSONArray(pkgsJson) } catch (_: Exception) { JSONArray() }
            val list = (0 until arr.length()).map { arr.getString(it) }
            val res = JSONObject()
            Installer.installedVersions(this@MainActivity, list).forEach { (k, v) -> res.put(k, v) }
            return res.toString()
        }

        @JavascriptInterface fun download(id: String, url: String, pkg: String, title: String, sha256: String, size: String) {
            Installer.download(this@MainActivity, id, url, pkg, sha256, size.toLongOrNull() ?: 0L)
        }

        @JavascriptInterface fun launch(pkg: String) {
            val i = packageManager.getLaunchIntentForPackage(pkg) ?: return
            startActivity(i)
        }

        @JavascriptInterface fun uninstall(pkg: String) {
            startActivity(Intent(Intent.ACTION_DELETE, Uri.parse("package:$pkg")))
        }

        @JavascriptInterface fun canInstall(): Boolean = packageManager.canRequestPackageInstalls()
    }
}
